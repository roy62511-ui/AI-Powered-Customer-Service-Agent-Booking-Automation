# VASTU PANDIT JI — BUSINESS SERVICES KNOWLEDGE BASE

## 1. Business Overview

Business Name: Vastu Pandit Ji  
Website: https://vastupanditji.com

Vastu Pandit Ji provides Numerology-based consultation services and Architectural Vastu consultation services.

The AI assistant must provide information based on the official business service catalogue and must not invent services, prices, guarantees or policies.

## 2. NUMEROLOGY CONSULTATION SERVICES

### 2.1 Personal Name & Signature Correction
Price: ₹11,000

Description:
Diagnostic audit of official legal documents versus everyday calling names. Includes identification of previous correction failures, phonetic and compound number balancing, signature realignment and lucky letter formulation.

### 2.2 Newborn Baby Naming Suite
Price: ₹11,000

Description:
Astrological and numerical harmony cross-referenced with both parents' charts. Includes either new name synthesis with auspicious starting syllables/letters or validation of shortlisted names.

### 2.3 Baby Birth Time & Muhurat Window
Price: ₹5,100

Description:
Planetary transit mapping and identification of optimal delivery windows for scheduled C-sections, prioritizing long-term health, intellect and prosperity.

### 2.4 Mobile Number Frequency Selection
Price: ₹5,100

Description:
Diagnostic check of existing mobile number vibrations and selection of high-frequency, commercial-growth contact numbers.

### 2.5 Vehicle Registration Number & Color Harmony
Price: ₹5,100

Description:
Auspicious registration number combinations, compound frequency balancing and exterior/interior vehicle color compatibility.

### 2.6 House / Flat Number & Villa Name Alignment
Price: ₹5,100

Description:
Compound numerical vibration analysis of prospective flat/door numbers and energetic alignment of residential villa names.

### 2.7 Brand & Business Name Formulation
Price: ₹11,000

Description:
Testing and formulation of registered enterprise, trade and consumer brand names. Synchronizes commercial vibrations with founders' and directors' charts.

### 2.8 Corporate Logo & Color Vibration
Price: ₹5,100

Description:
Alignment of visual brand identity, geometry, typography and brand color palette with primary business element vectors: Fire, Earth, Metal, Water and Wood.

### 2.9 Partnership Compatibility & Board Alignment
Price: ₹5,100

Description:
Numerical synchronization of co-founders, business partners or board directors.

## 3. ALL-INCLUSIVE NUMEROLOGY MASTERY SUITE

Investment: ₹27,000

Total A-La-Carte Value: ₹57,700  
Advertised Savings: ₹30,700  
Advertised Savings Percentage: Approximately 53%

### Included Services

Two Signature Strategic Formulations:
1. Full Personal Name & Signature Alignment or Brand/Business Name Optimization.
2. Secondary Signature Suite: Baby Naming, Rebranding or Executive Alignment.

Seven Targeted Vibrational Modules:
1. Mobile Number Frequency Audit & Selection.
2. Vehicle Registration Number & Exterior/Interior Color Harmony.
3. Flat/House Number & Residential Property Name Alignment.
4. Corporate Logo & Geometry Frequency Review.
5. Partnership Compatibility & Co-Founder Board Alignment.
6. Auspicious Timing / Muhurat Window Mapping.
7. Signature Energetic Transit Matrix.

### Alternative Remedial Blueprint

If baby naming or Muhurat services do not apply, the business describes an alternative Comprehensive Personal & Residential Numerical Remedial Blueprint, valued at ₹11,000, included free.

This includes:
- Personalized Numerological Diagnostic Dossier.
- Core compound frequencies.
- Primary karmic blockages and missing planetary numbers.
- Personal and residential numerical remedial guidance.
- Favorable personal compass directions.
- Lucky color palettes and numerical balancing tools.

### Important Scope Limitation

The residential remedies in this bundle are based on Numerological and planetary grid charts.

They do NOT replace a full Architectural Vastu Audit.

A full Architectural Vastu Audit requires separate consultation and technical assessment.

Analytical Window: 7 Working Days.

## 4. ARCHITECTURAL VASTU CONSULTATION SERVICES

### 4.1 Remote Global Audit — 100% Online

Starting Price: ₹30,000

Baseline coverage: Up to 1,200 sq. ft. / approximately 133 sq. yards.

Final investment depends on:
- Total property area.
- Number of levels.
- Layout complexity.

Format:
Digital advisory with up to six structured milestone video/audio calls.

Scope:
- 16-zone precision energy grid using scaled floor plans and Google Earth satellite coordinates.
- Diagnostic audit of subterranean reservoirs, septic lines, borewells and overhead roof tanks.
- Resolution of up to four pre-submitted core family or business queries.
- Non-demolition remedial roadmap.

### 4.2 Signature Residential Audit — On-Site Consultation

Price: ₹51,000

Coverage: Properties up to 1,200 sq. ft. / approximately 133 sq. yards.

Format:
- Kolkata: In-person on-site inspection included.
- Domestic and international outstation: In-person visits available; client bears flight, local transport and accommodation expenses.

Scope:
- Physical directional and compass degree verification.
- Structural load, beam, kitchen fire vector and septic/water placement balancing.
- Review of up to four core life/financial queries.
- Prioritized non-demolition remedial implementation blueprint.

### 4.3 Retail & Commercial Shops Above 1,200 Sq. Ft.

Starting Price: ₹1,00,000

Final quotation depends on total area, operational complexity and required on-site visits.

Scope:
- Custom assessment.
- Raw material to dispatch flow.
- Administrative cabins.
- Transformer/boiler fire vectors.
- Effluent/drainage grid balancing.

Kolkata on-site visits are included. Outstation domestic and international travel and accommodation expenses are borne by the client.

## 5. IMPORTANT SERVICE DISTINCTIONS

1. Numerology-based residential remedies are not equivalent to a full Architectural Vastu Audit.
2. The ₹27,000 Numerology Mastery Suite does not include a full Architectural Vastu Audit.
3. Remote Global Audit and Signature Residential Audit are separate services.
4. Remote Global Audit starts at ₹30,000 and is subject to area and complexity.
5. Signature Residential Audit costs ₹51,000 for properties up to 1,200 sq. ft.
6. Commercial properties above 1,200 sq. ft. require a bespoke quotation.
7. Baby Birth Time & Muhurat Window is listed as a service but must not be described as a general Kundli/Horoscope consultation.

## 6. CURRENTLY UNAVAILABLE SERVICES

Kundli / Horoscope Consultation is not currently listed as an available consultation service.

If a customer asks about it, the AI must politely explain that this service is not currently available.

The AI must not advertise it, accept a booking for it or claim that it is available.

## 7. AI ASSISTANT RULES

- Answer business-related questions using this approved service information.
- Respond in Bengali, Hindi or English according to the customer's language.
- Ask one relevant question at a time.
- Explain the differences between Numerology and Architectural Vastu clearly.
- Do not invent additional services or package inclusions.
- Do not promise guaranteed financial, health, relationship or business outcomes.
- Do not invent discounts, availability, payment policies or refund policies.
- If a question requires information not available here, direct the customer to the official business team.
- Do not claim that a customer enquiry or booking has been saved unless the backend actually confirms it.

## 8. SOURCE AND UPDATE POLICY

This document is based on the service descriptions and prices supplied from the Vastu Pandit Ji consultancy page.

Any changes to service availability, package inclusions, prices or business policies must be approved by the business team before updating this Knowledge Base.