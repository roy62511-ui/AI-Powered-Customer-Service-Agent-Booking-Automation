Put your knowledge base files here (.md only), for example:

01_VASTU_PANDIT_JI_BUSINESS_SERVICES.md
02_NUMEROLOGY_SERVICE_FAQ.md
03_ARCHITECTURAL_VASTU_SERVICE_FAQ.md
04_BOOKING_AND_PAYMENT_POLICIES.md
05_AI_CUSTOMER_CONVERSATION_RULES.md
06_AI_TEST_CASES.md

They are loaded in filename order, uploaded ONCE to Gemini as a cached context,
and are NOT sent again with each chat message.

After editing a file, either restart the server or call:
  curl -X POST http://localhost:3000/api/admin/reload -H "x-admin-key: YOUR_ADMIN_KEY"
