// =====================================================================================
// BOOKING CATALOGUE
//
// `code` is the exact value your server expects in `consultation_type`.
//   - code: '<value>'  -> the chatbot can book this service online (details -> review card -> Razorpay).
//   - code: null       -> the chatbot still explains the service and its price, but does NOT start an
//                         online booking; it sends the customer to the official team instead.
//
// To enable another service: replace its `code: null` with the real consultation_type string,
// then restart the server (or call POST /api/admin/reload).
// =====================================================================================

export const SERVICES = [
  // ---- Numerology ----
  { id: 'personal_name_signature_correction', category: 'numerology', name: 'Personal Name & Signature Correction', price: '₹11,000', code: null },
  { id: 'newborn_baby_naming_suite', category: 'numerology', name: 'Newborn Baby Naming Suite', price: '₹11,000', code: null },
  { id: 'baby_birth_time_muhurat_window', category: 'numerology', name: 'Baby Birth Time & Muhurat Window', price: '₹5,100', code: null },
  { id: 'mobile_number_frequency_selection', category: 'numerology', name: 'Mobile Number Frequency Selection', price: '₹5,100', code: null },
  { id: 'vehicle_number_color_harmony', category: 'numerology', name: 'Vehicle Registration Number & Color Harmony', price: '₹5,100', code: null },
  { id: 'house_flat_number_villa_name', category: 'numerology', name: 'House / Flat Number & Villa Name Alignment', price: '₹5,100', code: null },
  { id: 'brand_business_name_formulation', category: 'numerology', name: 'Brand & Business Name Formulation', price: '₹11,000', code: null },
  { id: 'corporate_logo_color_vibration', category: 'numerology', name: 'Corporate Logo & Color Vibration', price: '₹5,100', code: null },
  { id: 'partnership_compatibility_board_alignment', category: 'numerology', name: 'Partnership Compatibility & Board Alignment', price: '₹5,100', code: null },
  { id: 'numerology_mastery_suite', category: 'numerology', name: 'All-Inclusive Numerology Mastery Suite', price: '₹27,000', code: 'numerical_harmony_360_bundle' },

  // ---- Architectural Vastu ----
  { id: 'remote_global_audit', category: 'architectural', name: 'Remote Global Audit', price: 'Starting at ₹30,000', code: null },
  { id: 'signature_residential_audit', category: 'architectural', name: 'Signature Residential Audit', price: '₹51,000', code: null },
  { id: 'commercial_shops_audit', category: 'architectural', name: 'Retail & Commercial Shops Above 1,200 Sq. Ft.', price: 'Starting at ₹1,00,000', code: null },
];

const COMMON = ['full_name', 'whatsapp_number', 'email_address', 'client_timezone', 'mobile_number', 'address'];
const QUESTIONS = ['spot_question_1', 'spot_question_2', 'spot_question_3', 'spot_question_4'];

// Which details are collected per category. These are assumptions based on your sample
// request — your server remains the final authority and any validation message it returns
// is passed back to the customer.
export const FIELD_SETS = {
  numerology: {
    required: [...COMMON, 'date_of_birth', 'time_and_place_of_birth'],
    optional: QUESTIONS,
  },
  architectural: {
    required: [...COMMON, 'property_type', 'property_status'],
    optional: ['property_media_link', 'primary_focus', ...QUESTIONS],
  },
};
