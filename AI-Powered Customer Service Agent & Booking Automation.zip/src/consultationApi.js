// Client for the Vastu Pandit Ji consultation server:
//   POST {BASE}/consultations/submit          (multipart/form-data)
//   POST {BASE}/consultations/verify-payment  (JSON)

const BASE = (process.env.CONSULTATION_API_BASE_URL || '').replace(/\/+$/, '');
const TIMEOUT_MS = Number(process.env.CONSULTATION_API_TIMEOUT_MS || 20000);
// SECURITY: with test_mode=true your server accepts ANY signature. Never enable in production.
const TEST_MODE = String(process.env.PAYMENT_TEST_MODE || '').toLowerCase() === 'true';

export class ApiError extends Error {
  constructor(internal, httpStatus, publicMessage) {
    super(internal);
    this.httpStatus = httpStatus;
    this.publicMessage = publicMessage;
  }
}

export const apiConfig = () => ({ configured: Boolean(BASE), testMode: TEST_MODE });

async function call(path, init) {
  if (!BASE) {
    throw new ApiError('CONSULTATION_API_BASE_URL is not set', 503, 'Online booking is not available right now. Please contact our official team.');
  }

  let res;
  try {
    res = await fetch(BASE + path, { ...init, signal: AbortSignal.timeout(TIMEOUT_MS) });
  } catch (err) {
    throw new ApiError(`network error calling ${path}: ${err.message}`, 502, 'We could not reach the booking system. Please try again in a moment.');
  }

  const raw = await res.text();
  let json = null;
  try {
    json = JSON.parse(raw);
  } catch {
    /* non-JSON body */
  }

  if (!res.ok || !json || json.success === false) {
    const serverMsg = typeof json?.message === 'string' ? json.message.slice(0, 200) : null;
    const clientError = res.status >= 400 && res.status < 500;
    throw new ApiError(
      `${path} -> HTTP ${res.status}: ${raw.slice(0, 300)}`,
      clientError ? 400 : 502,
      clientError && serverMsg ? serverMsg : 'The booking system had a problem. Please try again shortly.',
    );
  }
  return json;
}

/** Creates the consultation + Razorpay order. Returns the normalized order. */
export async function submitConsultation(values, consultationType) {
  const form = new FormData();
  for (const [k, v] of Object.entries(values)) if (v) form.append(k, v);
  form.append('consultation_type', consultationType);
  form.append('policy_consent_checkbox', 'true');

  const json = await call('/consultations/submit', { method: 'POST', body: form });
  const d = json.data || {};
  if (!d.consultation_id || !d.razorpay_order_id || !d.razorpay_key_id || !d.amount_paise) {
    throw new ApiError(`submit response missing fields: ${JSON.stringify(json).slice(0, 300)}`, 502, 'The booking system returned an unexpected response. Please try again.');
  }
  return {
    consultation_id: d.consultation_id,
    razorpay_order_id: d.razorpay_order_id,
    razorpay_key_id: d.razorpay_key_id,
    amount: d.amount,
    amount_paise: d.amount_paise,
    currency: d.currency || 'INR',
  };
}

/** Confirms the Razorpay payment with your server. */
export async function verifyPayment({ consultation_id, razorpay_order_id, razorpay_payment_id, razorpay_signature, meeting_slot_date_time }) {
  const body = { consultation_id, razorpay_order_id, razorpay_payment_id, razorpay_signature, meeting_slot_date_time };
  if (TEST_MODE) body.test_mode = true;
  return call('/consultations/verify-payment', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}
