import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SERVICES, FIELD_SETS } from '../config/services.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');
const PROMPT_FILE = path.join(ROOT, 'prompts', 'system.md');
const KNOWLEDGE_DIR = path.join(ROOT, 'knowledge');

function bookingCatalogue() {
  const bookable = SERVICES.filter((s) => s.code);
  const notBookable = SERVICES.filter((s) => !s.code);

  const lines = [
    '\n\n# BOOKING CATALOGUE (system-generated; authoritative for what can be booked in this chat)',
    '',
    'Bookable online in this chat (service_id | name | listed price):',
    ...(bookable.length ? bookable.map((s) => `- ${s.id} | ${s.name} | ${s.price}`) : ['- (none)']),
    '',
    'NOT bookable online in this chat yet. Explain these services and prices as usual, but do NOT start a booking; direct the customer to the official Vastu Pandit Ji team:',
    ...(notBookable.length ? notBookable.map((s) => `- ${s.name}`) : ['- (none)']),
    '',
    'Details to collect for a bookable service (pass them to prepare_booking):',
  ];

  for (const [category, set] of Object.entries(FIELD_SETS)) {
    lines.push(`- ${category} services. Required: ${set.required.join(', ')}. Optional: ${set.optional.join(', ')}.`);
  }
  lines.push(
    '',
    'Formats: date_of_birth = YYYY-MM-DD. whatsapp_number = with country code (e.g. +919876543210).',
    'Ask for "spot questions" (the customer\'s own questions, up to 4) once, as optional.',
  );
  return lines.join('\n');
}

/**
 * Builds the full instruction text: system prompt + every .md file in /knowledge + booking catalogue.
 * This text is uploaded to Gemini ONCE (as a cache), not with every message.
 */
export async function buildInstruction() {
  const system = await fs.readFile(PROMPT_FILE, 'utf8');

  let files = [];
  try {
    files = (await fs.readdir(KNOWLEDGE_DIR)).filter((f) => f.toLowerCase().endsWith('.md')).sort();
  } catch {
    // knowledge folder missing -> run with system prompt only
  }

  const docs = [];
  for (const file of files) {
    const text = await fs.readFile(path.join(KNOWLEDGE_DIR, file), 'utf8');
    docs.push(`\n\n=== KNOWLEDGE BASE DOCUMENT: ${file} ===\n${text.trim()}`);
  }

  const instruction =
    (docs.length ? `${system.trim()}\n\n# APPROVED KNOWLEDGE BASE (authoritative)${docs.join('')}` : system.trim()) +
    bookingCatalogue();

  return { instruction, fileCount: files.length };
}
