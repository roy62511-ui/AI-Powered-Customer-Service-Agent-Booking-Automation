import crypto from 'node:crypto';
import { GoogleGenAI } from '@google/genai';
import { buildInstruction } from './knowledge.js';
import { buildTools } from './tools.js';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  // Optional: only for proxies / local testing. Leave unset in normal use.
  ...(process.env.GEMINI_BASE_URL ? { httpOptions: { baseUrl: process.env.GEMINI_BASE_URL } } : {}),
});

// Primary model (also the one the knowledge cache is built for).
const MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
// Comma-separated backups, tried in order when the primary is overloaded.
const FALLBACKS = (process.env.GEMINI_FALLBACK_MODELS || process.env.GEMINI_FALLBACK_MODEL || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);
const MODELS = [...new Set([MODEL, ...FALLBACKS])];

const TTL_SECONDS = Number(process.env.CACHE_TTL_SECONDS || 3600);
const MAX_OUTPUT_TOKENS = Number(process.env.MAX_OUTPUT_TOKENS || 8192);
const THINKING_LEVEL = (process.env.THINKING_LEVEL || '').trim().toUpperCase();

const RENEW_MARGIN_MS = 60_000;
const RETRY_AFTER_FAILURE_MS = 5 * 60_000;
const OVERLOAD_COOLDOWN_MS = 60_000;
const UNAVAILABLE_COOLDOWN_MS = 10 * 60_000;

const MAX_TOOL_ROUNDS = 4;
const MAX_HISTORY_MESSAGES = 30;

const state = {
  instruction: '',
  tools: undefined,
  hash: '',
  fileCount: 0,
  cacheName: null,
  validUntil: 0,
  mode: 'inline', // 'cached' | 'inline'
};

let refreshing = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const isOverload = (err) => [429, 500, 503, 504].includes(err?.status);

// ---- per-model health tracking (circuit breaker) ----
const unhealthyUntil = new Map();
const markUnhealthy = (model, ms) => unhealthyUntil.set(model, Date.now() + ms);

function candidateModels() {
  const now = Date.now();
  const healthy = MODELS.filter((m) => (unhealthyUntil.get(m) || 0) <= now);
  return healthy.length ? healthy : MODELS;
}

// ---- knowledge cache ----
async function deleteCache(name) {
  if (!name) return;
  try {
    await ai.caches.delete({ name });
  } catch {
    /* already expired */
  }
}

async function doRefresh() {
  const { instruction, fileCount } = await buildInstruction();
  const tools = buildTools();
  const hash = crypto.createHash('sha256').update(instruction).update(JSON.stringify(tools || null)).digest('hex');

  const oldCache = state.cacheName;
  state.instruction = instruction;
  state.tools = tools;
  state.hash = hash;
  state.fileCount = fileCount;

  try {
    const cache = await ai.caches.create({
      model: MODEL,
      config: {
        displayName: 'vastu-pandit-ji-kb',
        systemInstruction: instruction,
        // A cached request may not set tools itself, so the tool lives in the cache too.
        ...(tools ? { tools } : {}),
        ttl: `${TTL_SECONDS}s`,
      },
    });
    state.cacheName = cache.name;
    state.mode = 'cached';
    state.validUntil = Date.now() + TTL_SECONDS * 1000 - RENEW_MARGIN_MS;
    console.log(`[gemini] knowledge cached (${fileCount} files) -> ${cache.name}`);
  } catch (error) {
    console.error('[gemini] Cache creation failed:', {
      message: error.message,
      status: error.status,
      code: error.code,
      details: error.details,
      stack: error.stack,
    });

    state.mode = 'inline';
    console.log('[gemini] Using inline instructions');
  }

  if (oldCache && oldCache !== state.cacheName) await deleteCache(oldCache);
}

/** (Re)load files and (re)create the Gemini cache. Safe to call concurrently. */
export function refreshKnowledge() {
  if (!refreshing) {
    refreshing = doRefresh().finally(() => {
      refreshing = null;
    });
  }
  return refreshing;
}

async function ensureReady() {
  if (Date.now() >= state.validUntil) await refreshKnowledge();
}

export function getStatus() {
  const now = Date.now();
  return {
    model: MODEL,
    models: MODELS,
    coolingDown: MODELS.filter((m) => (unhealthyUntil.get(m) || 0) > now),
    mode: state.mode,
    knowledgeFiles: state.fileCount,
    bookingTool: Boolean(state.tools),
    cacheName: state.cacheName,
    contentHash: state.hash.slice(0, 12),
  };
}

function buildConfig(useCache, model) {
  const config = { maxOutputTokens: MAX_OUTPUT_TOKENS };
  if (THINKING_LEVEL && model === MODEL) config.thinkingConfig = { thinkingLevel: THINKING_LEVEL };
  if (useCache && state.cacheName) {
    config.cachedContent = state.cacheName;
  } else {
    config.systemInstruction = state.instruction;
    if (state.tools) config.tools = state.tools;
  }
  return config;
}

/**
 * One model call (streamed) with failover across models.
 * Text is passed to onText as it arrives. Returns { model, parts, calls }.
 * `parts` are the model's raw content parts (kept as-is: Gemini 3 needs thought signatures
 * to be sent back unchanged when a function call is part of the conversation).
 * If `onlyModel` is set (follow-up call after a tool result) no other model is used.
 */
async function streamOnce(contents, onText, onlyModel) {
  let lastErr;
  for (let round = 0; round < 2; round++) {
    if (round) await sleep(1000);

    const models = onlyModel ? [onlyModel] : candidateModels();
    for (const model of models) {
      let started = false;
      try {
        const useCache = model === MODEL && Boolean(state.cacheName);
        const stream = await ai.models.generateContentStream({ model, contents, config: buildConfig(useCache, model) });

        const parts = [];
        const calls = [];
        for await (const chunk of stream) {
          for (const part of chunk.candidates?.[0]?.content?.parts || []) {
            if (part.functionCall) {
              calls.push(part.functionCall);
              parts.push(part);
              started = true;
            } else if (part.text && !part.thought) {
              onText(part.text);
              parts.push(part);
              started = true;
            } else if (part.thoughtSignature) {
              parts.push(part);
            }
          }
        }
        return { model, parts, calls };
      } catch (err) {
        lastErr = err;
        console.warn(`[gemini] ${model} failed (${err.status ?? 'no status'}): ${String(err.message).slice(0, 160)}`);

        if (started) throw err; // output already sent; cannot switch models mid-reply

        if (isOverload(err)) {
          markUnhealthy(model, OVERLOAD_COOLDOWN_MS);
          continue;
        }
        if (model === MODEL && state.cacheName && /cache|cached/i.test(String(err.message))) {
          state.validUntil = 0;
          await ensureReady();
          continue;
        }
        if (err.status === 404 || (model !== MODEL && err.status === 400)) {
          markUnhealthy(model, UNAVAILABLE_COOLDOWN_MS);
          continue;
        }
        throw err;
      }
    }
  }
  throw lastErr;
}

/** Keep the history bounded, and always starting at a plain user text turn (never mid tool-call). */
export function trimHistory(history) {
  if (history.length > MAX_HISTORY_MESSAGES) history.splice(0, history.length - MAX_HISTORY_MESSAGES);
  while (history.length && !(history[0].role === 'user' && history[0].parts?.some((p) => typeof p.text === 'string'))) {
    history.shift();
  }
}

/**
 * Runs one customer message: streams text via onText, executes tool calls via executeTool,
 * and stores the finished turn in session.history.
 */
export async function runChat(session, message, { onText, executeTool }) {
  await ensureReady();

  const contents = [...session.history, { role: 'user', parts: [{ text: message }] }];
  let onlyModel = null;
  let spoke = false;

  for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
    const result = await streamOnce(
      contents,
      (t) => {
        spoke = true;
        onText(t);
      },
      onlyModel,
    );

    if (result.parts.length) contents.push({ role: 'model', parts: result.parts });
    if (!result.calls.length) break;

    onlyModel = result.model;
    const responses = [];
    for (const call of result.calls) {
      let output;
      try {
        output = await executeTool(call.name, call.args || {});
      } catch (err) {
        console.error(`[tool] ${call.name} threw:`, err.message);
        output = { status: 'error', instruction: 'The booking tool failed. Apologise briefly and ask the customer to try again shortly.' };
      }
      responses.push({ functionResponse: { ...(call.id ? { id: call.id } : {}), name: call.name, response: output } });
    }
    contents.push({ role: 'user', parts: responses });
  }

  if (!spoke) {
    const fallback = 'Sorry, I could not generate a reply. Please try again.';
    onText(fallback);
    contents.push({ role: 'model', parts: [{ text: fallback }] });
  }

  session.history.splice(0, session.history.length, ...contents);
  trimHistory(session.history);
}
