import { SERVICES, FIELD_SETS } from '../config/services.js';

export const LANGUAGES = ['en', 'hi', 'bn', 'hinglish'];

export const bookableServices = () => SERVICES.filter((s) => s.code);
export const getService = (id) => SERVICES.find((s) => s.id === id);

// ---------- input cleaning & validation ----------

const clean = (v) =>
  typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim() : '';

const stripPhone = (v) => v.replace(/[\s\-().]/g, '');

const NORMALIZE = {
  whatsapp_number: stripPhone,
  mobile_number: stripPhone,
  email_address: (v) => v.toLowerCase(),
};

const len = (min, max) => (v) => (v.length >= min && v.length <= max ? null : `must be ${min}-${max} characters`);

const RULES = {
  full_name: len(2, 100),
  whatsapp_number: (v) => (/^\+[1-9]\d{9,14}$/.test(v) ? null : 'must include the country code, e.g. +919876543210'),
  mobile_number: (v) => (/^\+?\d{10,15}$/.test(v) ? null : 'must be a valid phone number (10-15 digits)'),
  email_address: (v) => (v.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? null : 'is not a valid email address'),
  client_timezone: len(2, 50),
  address: len(5, 300),
  date_of_birth: (v) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return 'must be in YYYY-MM-DD format';
    const d = new Date(`${v}T00:00:00Z`);
    if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v) return 'is not a valid date';
    if (d > new Date() || d < new Date('1900-01-01T00:00:00Z')) return 'is out of range';
    return null;
  },
  time_and_place_of_birth: len(3, 200),
  property_type: len(2, 50),
  property_status: len(2, 50),
  property_media_link: (v) => {
    try {
      const u = new URL(v);
      return (u.protocol === 'http:' || u.protocol === 'https:') && v.length <= 500 ? null : 'must be an http(s) link';
    } catch {
      return 'must be a valid link';
    }
  },
  primary_focus: len(2, 300),
  spot_question_1: len(2, 500),
  spot_question_2: len(2, 500),
  spot_question_3: len(2, 500),
  spot_question_4: len(2, 500),
};

/** Validates the model's tool arguments. Never trusts them. */
export function validateBooking(args) {
  const input = args && typeof args === 'object' ? args : {};
  const service = getService(clean(input.service_id));
  if (!service) return { ok: false, problems: [{ field: 'service_id', problem: 'unknown service' }] };
  if (!service.code) return { ok: false, notBookable: true, service, problems: [] };

  const set = FIELD_SETS[service.category];
  const values = {};
  const problems = [];

  const check = (field, isRequired) => {
    let v = clean(input[field]);
    if (!v) {
      if (isRequired) problems.push({ field, problem: 'missing' });
      return;
    }
    if (NORMALIZE[field]) v = NORMALIZE[field](v);
    const err = RULES[field]?.(v);
    if (err) problems.push({ field, problem: err });
    else values[field] = v;
  };

  set.required.forEach((f) => check(f, true));
  set.optional.forEach((f) => check(f, false));

  const language = LANGUAGES.includes(input.language) ? input.language : 'en';
  return { ok: problems.length === 0, service, values, language, problems };
}

/** Accepts an ISO-8601 UTC timestamp in the future; returns it as YYYY-MM-DDTHH:mm:ssZ, or null. */
export function parseSlot(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?Z$/.test(value)) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  const now = Date.now();
  if (d.getTime() <= now || d.getTime() > now + 365 * 24 * 3600 * 1000) return null;
  return d.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

// ---------- the model's tool ----------

/**
 * Tool exposed to Gemini. NOTE: it does not submit anything. It validates the details and shows the
 * customer a review card. Only the customer's button click (POST /api/booking/confirm) sends data on.
 */
export function prepareBooking(session, args, emit) {
  const current = session.booking;
  if (current && (current.status === 'submitting' || current.status === 'verifying')) {
    return { status: 'busy', instruction: 'A booking step is already in progress. Ask the customer to wait a moment.' };
  }

  const v = validateBooking(args);

  if (v.notBookable) {
    return {
      status: 'not_bookable',
      instruction: `"${v.service.name}" cannot be booked online in this chat yet. Explain the service and price, then direct the customer to the official Vastu Pandit Ji team.`,
    };
  }
  if (!v.ok) {
    return {
      status: 'invalid',
      problems: v.problems,
      instruction:
        'Ask the customer ONLY for the missing or incorrect details (in their language, 2-3 at a time), then call prepare_booking again with ALL details. Do not claim anything has been booked.',
    };
  }

  const set = FIELD_SETS[v.service.category];
  const ordered = [...set.required, ...set.optional].filter((f) => v.values[f]);

  session.booking = {
    status: 'draft',
    service: { id: v.service.id, name: v.service.name, price: v.service.price, code: v.service.code },
    values: v.values,
    language: v.language,
    createdAt: Date.now(),
  };

  emit({
    type: 'booking_review',
    language: v.language,
    service: { name: v.service.name, price: v.service.price },
    fields: ordered.map((key) => ({ key, value: v.values[key] })),
    policyUrl: process.env.POLICY_URL || null,
  });

  return {
    status: 'review_card_shown',
    instruction:
      'A booking summary card is now on the customer\'s screen. In 1-2 short sentences (customer\'s language) tell them to review it, tick the consent box, choose a preferred meeting date and time, and press the confirm button, which opens the secure Razorpay payment window. Nothing has been booked, sent or paid yet; do not say otherwise.',
  };
}

export function publicOrder(b) {
  return {
    consultation_id: b.order.consultation_id,
    razorpay_order_id: b.order.razorpay_order_id,
    razorpay_key_id: b.order.razorpay_key_id,
    amount: b.order.amount,
    amount_paise: b.order.amount_paise,
    currency: b.order.currency,
    service_name: b.service.name,
    full_name: b.values.full_name,
    email_address: b.values.email_address,
    whatsapp_number: b.values.whatsapp_number,
  };
}
