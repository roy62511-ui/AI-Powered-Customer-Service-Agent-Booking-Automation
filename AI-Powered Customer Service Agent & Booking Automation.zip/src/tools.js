import { bookableServices, LANGUAGES } from './booking.js';

const str = (description) => ({ type: 'STRING', description });

/** Gemini function declarations. Returns undefined when no service is bookable yet. */
export function buildTools() {
  const ids = bookableServices().map((s) => s.id);
  if (!ids.length) return undefined;

  return [
    {
      functionDeclarations: [
        {
          name: 'prepare_booking',
          description:
            'Call ONLY after the customer has confirmed the service they want to book AND agreed to share their details. ' +
            'Validates the details and shows the customer a booking review card. It does NOT book or charge anything: ' +
            'the customer must still tick consent and press the confirm button themselves. ' +
            'Pass exactly what the customer told you; never invent values.',
          parameters: {
            type: 'OBJECT',
            properties: {
              service_id: { type: 'STRING', enum: ids, description: 'The service the customer confirmed.' },
              language: { type: 'STRING', enum: LANGUAGES, description: 'Language the customer is writing in (hinglish = Hindi in Roman script).' },
              full_name: str('Customer full name.'),
              whatsapp_number: str('WhatsApp number WITH country code, e.g. +919876543210.'),
              email_address: str('Customer email address.'),
              client_timezone: str('Customer time zone as they state it, e.g. IST.'),
              mobile_number: str('Customer mobile number (may be the same as the WhatsApp number).'),
              address: str('Customer address (city/area is enough if that is all they provide).'),
              date_of_birth: str('Date of birth in YYYY-MM-DD format (numerology services).'),
              time_and_place_of_birth: str('Time and place of birth, e.g. "12:00, Barasat" (numerology services).'),
              property_type: str('Property type, e.g. residential or commercial (architectural services).'),
              property_status: str('Property status, e.g. under_construction (architectural services).'),
              property_media_link: str('Link to floor plan / photos (architectural services, optional).'),
              primary_focus: str('Main concern the customer wants addressed (optional).'),
              spot_question_1: str('Customer question 1 (optional).'),
              spot_question_2: str('Customer question 2 (optional).'),
              spot_question_3: str('Customer question 3 (optional).'),
              spot_question_4: str('Customer question 4 (optional).'),
            },
            required: ['service_id', 'language', 'full_name', 'whatsapp_number', 'email_address', 'client_timezone'],
          },
        },
      ],
    },
  ];
}
