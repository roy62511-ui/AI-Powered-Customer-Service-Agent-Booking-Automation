import 'dotenv/config';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { runChat, refreshKnowledge, getStatus } from './src/gemini.js';
import { prepareBooking, publicOrder, parseSlot, bookableServices } from './src/booking.js';
import { submitConsultation, verifyPayment, apiConfig } from './src/consultationApi.js';
import cors from 'cors';

if (!process.env.GEMINI_API_KEY) {
  console.error('Missing GEMINI_API_KEY in .env');
  process.exit(1);
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);

const MAX_MESSAGE_CHARS = 1000;
const SESSION_IDLE_MS = 30 * 60_000;
const PAYMENT_IDLE_MS = 3 * 60 * 60_000; // keep sessions with an unfinished payment much longer

app.set('trust proxy', Number(process.env.TRUST_PROXY || 0));

app.use(cors({
  origin: (origin, callback) => {
    console.log('Request Origin:', origin);

    // Postman / server-to-server
    if (!origin) {
      return callback(null, true);
    }

    // Local development
    const isLocalhost =
      /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);

    // Production frontend
    const allowedOrigins = [
      'https://vastupanditji.com',
      'https://www.vastupanditji.com',
    ];

    if (isLocalhost || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }

    return callback(new Error(`Not allowed by CORS: ${origin}`));
  },

  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Admin-Key'],
  credentials: true,
}));

app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ---------- in-memory sessions (lost on restart; chat text is never written to disk) ----------
const sessions = new Map(); // id -> { history, booking, touched }
const ACTIVE_PAYMENT = new Set(['submitting', 'pending_payment', 'verifying']);

setInterval(() => {
  const now = Date.now();
  for (const [id, s] of sessions) {
    const limit = ACTIVE_PAYMENT.has(s.booking?.status) ? PAYMENT_IDLE_MS : SESSION_IDLE_MS;
    if (now - s.touched > limit) sessions.delete(id);
  }
}, 5 * 60_000).unref();

function getOrCreateSession(id) {
  if (typeof id === 'string' && sessions.has(id)) {
    const s = sessions.get(id);
    s.touched = Date.now();
    return { id, session: s };
  }
  const newId = crypto.randomUUID();
  const s = { history: [], booking: null, touched: Date.now() };
  sessions.set(newId, s);
  return { id: newId, session: s };
}

function getExistingSession(id) {
  const s = typeof id === 'string' ? sessions.get(id) : null;
  if (s) s.touched = Date.now();
  return s || null;
}

// Customers must not be able to forge the booking system's notes to the model.
const sanitizeUserText = (t) => t.replace(/\[\s*SYSTEM/gi, '(SYSTEM');

// ---------- rate limits ----------
const jsonLimit = (limit, error) =>
  rateLimit({ windowMs: 60_000, limit, standardHeaders: true, legacyHeaders: false, message: { error } });
const chatLimiter = jsonLimit(20, 'Too many messages. Please wait a minute and try again.');
const bookingLimiter = jsonLimit(15, 'Too many attempts. Please wait a minute and try again.');

// ---------- chat (streamed as newline-delimited JSON) ----------
app.post('/api/chat', chatLimiter, async (req, res) => {
  const raw = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  if (!raw) return res.status(400).json({ error: 'Message is required.' });
  if (raw.length > MAX_MESSAGE_CHARS) {
    return res.status(400).json({ error: `Message too long (max ${MAX_MESSAGE_CHARS} characters).` });
  }
  const message = sanitizeUserText(raw);

  const { id, session } = getOrCreateSession(req.body?.sessionId);

  res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('X-Accel-Buffering', 'no');
  res.setHeader('X-Session-Id', id);

  const emit = (obj) => res.write(JSON.stringify(obj) + '\n');

  try {
    await runChat(session, message, {
      onText: (text) => emit({ type: 'text', text }),
      executeTool: async (name, args) => {
        if (name !== 'prepare_booking') return { status: 'error', instruction: 'Unknown tool.' };
        return prepareBooking(session, args, emit);
      },
    });
    session.touched = Date.now();
    res.end();
  } catch (err) {
    console.error('[chat] error:', err.message);
    if (!res.headersSent) {
      return res.status(502).json({ error: 'The assistant is unavailable right now. Please try again shortly.' });
    }
    emit({ type: 'error', message: 'The reply was interrupted. Please try again.' });
    res.end();
  }
});

app.post('/api/reset', (req, res) => {
  const s = getExistingSession(req.body?.sessionId);
  // Never drop a session that is in the middle of a payment.
  if (s && !ACTIVE_PAYMENT.has(s.booking?.status)) sessions.delete(req.body.sessionId);
  res.json({ ok: true });
});

// ---------- booking: customer pressed "Confirm" -> create consultation + Razorpay order ----------
app.post('/api/booking/confirm', bookingLimiter, async (req, res) => {
  const session = getExistingSession(req.body?.sessionId);
  if (!session) return res.status(404).json({ error: 'Your session has expired. Please start the booking again in the chat.' });

  const b = session.booking;
  if (!b) return res.status(400).json({ error: 'There is no booking to confirm.' });

  // Idempotent: reload / double click returns the same order instead of creating a second one.
  if (b.status === 'pending_payment') return res.json({ ok: true, order: publicOrder(b) });
  if (b.status !== 'draft') return res.status(409).json({ error: 'This booking can no longer be changed.' });

  if (req.body?.consent !== true) return res.status(400).json({ error: 'Please accept the policies to continue.' });
  const slot = parseSlot(req.body?.slot);
  if (!slot) return res.status(400).json({ error: 'Please choose a valid future date and time.' });

  b.status = 'submitting';
  try {
    b.order = await submitConsultation(b.values, b.service.code);
    b.slot = slot;
    b.status = 'pending_payment';
    console.log(`[booking] order created consultation=${b.order.consultation_id} order=${b.order.razorpay_order_id}`);
    res.json({ ok: true, order: publicOrder(b) });
  } catch (err) {
    b.status = 'draft';
    console.error('[booking] submit failed:', err.message);
    res.status(err.httpStatus || 502).json({ error: err.publicMessage || 'Could not create your booking. Please try again.' });
  }
});

// ---------- booking: Razorpay checkout succeeded -> verify with your server ----------
app.post('/api/booking/verify', bookingLimiter, async (req, res) => {
  const session = getExistingSession(req.body?.sessionId);
  if (!session) return res.status(404).json({ error: 'Your session has expired. Please contact our official team with your payment reference.' });

  const b = session.booking;
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};

  if (!b?.order) return res.status(400).json({ error: 'No payment is pending for this chat.' });
  if (
    typeof razorpay_order_id !== 'string' ||
    typeof razorpay_payment_id !== 'string' ||
    typeof razorpay_signature !== 'string' ||
    razorpay_order_id !== b.order.razorpay_order_id ||
    !/^pay_[A-Za-z0-9]+$/.test(razorpay_payment_id) ||
    !/^[A-Za-z0-9_-]{10,200}$/.test(razorpay_signature)
  ) {
    return res.status(400).json({ error: 'This payment does not match your booking.' });
  }

  const confirmation = () => ({
    consultation_id: b.order.consultation_id,
    service_name: b.service.name,
    amount: b.order.amount,
    currency: b.order.currency,
    payment_id: b.paymentId,
    slot: b.slot,
    language: b.language,
  });

  if (b.status === 'paid') {
    return b.paymentId === razorpay_payment_id
      ? res.json({ ok: true, confirmation: confirmation() })
      : res.status(409).json({ error: 'This booking is already paid.' });
  }
  if (b.status !== 'pending_payment') return res.status(409).json({ error: 'Payment is already being confirmed. Please wait a moment.' });

  b.status = 'verifying';
  try {
    await verifyPayment({
      consultation_id: b.order.consultation_id,
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      meeting_slot_date_time: b.slot,
    });
    b.paymentId = razorpay_payment_id;
    b.status = 'paid';
    console.log(`[booking] PAID consultation=${b.order.consultation_id} payment=${razorpay_payment_id}`);

    // Let the assistant know (trusted, server-written) so follow-up chat stays accurate.
    session.history.push(
      { role: 'user', parts: [{ text: `[SYSTEM NOTE] Payment verified by the booking system for "${b.service.name}". Consultation ID ${b.order.consultation_id}. The thank-you confirmation card has already been shown to the customer; do not repeat it.` }] },
      { role: 'model', parts: [{ text: 'Noted: the booking is paid and confirmed by the booking system.' }] },
    );
    res.json({ ok: true, confirmation: confirmation() });
  } catch (err) {
    b.status = 'pending_payment'; // allow a retry of the same payment
    // The customer may have been charged: log every reference needed to reconcile manually.
    console.error(`[booking] VERIFY FAILED consultation=${b.order.consultation_id} order=${razorpay_order_id} payment=${razorpay_payment_id}: ${err.message}`);
    res.status(err.httpStatus || 502).json({ error: err.publicMessage || 'We could not confirm your payment yet.' });
  }
});

// ---------- ops ----------
app.get('/api/health', (_req, res) => {
  const api = apiConfig();
  res.json({
    ok: true,
    ...getStatus(),
    booking: { bookableServices: bookableServices().length, apiConfigured: api.configured, paymentTestMode: api.testMode },
  });
});

// Re-read knowledge/*.md, prompts/system.md and config/services.js, and rebuild the Gemini cache.
app.post('/api/admin/reload', async (req, res) => {
  const key = process.env.ADMIN_KEY;
  if (!key || req.get('x-admin-key') !== key) return res.status(401).json({ error: 'Unauthorized' });
  try {
    await refreshKnowledge();
    res.json({ ok: true, ...getStatus() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------- start ----------
await refreshKnowledge();
app.listen(PORT, () => {
  const s = getStatus();
  const api = apiConfig();
  console.log(`Vastu Pandit Ji chat running on http://localhost:${PORT}  [${s.mode}, ${s.knowledgeFiles} knowledge files]`);
  if (!api.configured) console.warn('[booking] CONSULTATION_API_BASE_URL is not set: online booking will be unavailable.');
  if (api.testMode) console.warn('[booking] PAYMENT_TEST_MODE=true: your server will accept ANY payment signature. Never use in production.');
});
