# Vastu Pandit Ji — AI Support Chat (Node.js + Express + Gemini)

Answers customer questions from your knowledge files and can **book and take payment** for consultations.

## Setup

```bash
npm install
cp .env.example .env      # fill GEMINI_API_KEY, ADMIN_KEY, CONSULTATION_API_BASE_URL
npm start                 # http://localhost:3000
```

## Booking flow

1. Customer chats; the AI confirms the **service and price**, asks permission, then collects the details.
2. The AI calls its `prepare_booking` tool. **The tool sends nothing.** It validates the details and shows a **review card**.
3. The customer ticks the consent box, picks a preferred meeting date/time, and presses **Confirm**.
   Only then does the server call `POST {CONSULTATION_API_BASE_URL}/consultations/submit` (multipart form).
4. The server returns the Razorpay order; the browser opens **Razorpay Checkout**.
5. On success the browser sends the payment to `POST /api/booking/verify`; the server calls
   `POST {CONSULTATION_API_BASE_URL}/consultations/verify-payment`.
6. The **thank-you confirmation card** appears. The AI is told the booking is paid, so follow-up chat stays accurate.

The AI can never submit a booking or take a payment by itself: a human click on the card is required.

## Enabling more services

Open `config/services.js`. Only services with a `code` (the exact `consultation_type` your server expects)
can be booked online; the rest are explained by the AI and referred to your team. Put the real code in,
then restart (or call `/api/admin/reload`).

## Where things live

| Path | Purpose |
|---|---|
| `prompts/system.md` | System prompt (sections 8, 9, 9A cover booking) |
| `knowledge/*.md` | Knowledge base, uploaded once to Gemini (not sent with every message) |
| `config/services.js` | Bookable services, their `consultation_type` codes, required fields |
| `src/gemini.js` | Gemini calls, function calling, caching, model failover |
| `src/booking.js` | Validation, review card, session booking state |
| `src/consultationApi.js` | Calls to your `/consultations/submit` and `/verify-payment` |
| `server.js` | Express API |
| `public/index.html` | Chat UI, review card, Razorpay checkout, thank-you card |

## API

| Route | Purpose |
|---|---|
| `POST /api/chat` | Streams the reply as newline-delimited JSON (`text`, `booking_review`, `error` events) |
| `POST /api/booking/confirm` | Customer confirmed: creates consultation + Razorpay order |
| `POST /api/booking/verify` | Razorpay succeeded: verifies payment with your server |
| `GET /api/health` | Model, cache mode, booking configuration |
| `POST /api/admin/reload` | Re-read prompt, knowledge and services (header `x-admin-key`) |

## Important notes

- **`PAYMENT_TEST_MODE`**: when `true`, the server sends `test_mode: true` to verify-payment, which makes your
  backend accept *any* signature. Keep it `false` in production.
- **Razorpay Checkout needs HTTPS** on a public domain (http://localhost is fine for testing).
- **Sessions live in memory.** If the server restarts while a customer is paying, the verify step cannot run.
  The server logs every reference (`[booking] VERIFY FAILED ...`) so the payment can be reconciled by hand.
  For production, keep sessions in Redis/PostgreSQL.
- Knowledge files 04, 05 and 06 were updated so they no longer tell the AI it cannot book. Review them.
- Use the knowledge cache with `GET /api/health` (`mode: "cached"` or `"inline"`).
